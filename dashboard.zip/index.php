<?php include 'header.php';?>
 
    <div class="navbar_div">
        <div class="logo_li">
            <a href="#"> 
                <img src="https://alumni.ulab.edu.bd/sites/all/themes/sloth/logo.svg" alt="logo">
            </a>
        </div> 
        <ul> 
            <li><a href="#home">Home</a></li>
            <li><a href="#news">Blood</a></li>
            <li><a href="#news">Profile</a></li> 
            <li><a href="#news">Notice</a></li>
            <li><a href="#news">Alumni List</a></li>
            <li><a href="#contact">News & Events</a></li> 
            <li><a href="#news">Contact Us</a></li> 
            <li><a href="#news">Sign In</a></li> 
        </ul>
    </div>
 

<?php include 'footer.php';?>